import React, { Component } from "react";
import "./App.css";
import MyModal from "./Components/MyModal";

// import ModalComponent from "./Components/ModalComponent";

class App extends Component {
  render() {
    return (
      <div className="App">
        <MyModal />
      </div>
    );
  }
}

export default App;
